<?php  
defined('BASEPATH') OR exit('No direct script access allowed');  
  
class Home extends CI_Controller {  
      
    public function index()  
    {  

/*   $this->load->view('sign-in');*/
  
  $username= $this->input->post('username');
  $password= $this->input->post('password');
  $query = $this->Insert->adminlogin($username,$password);
 
  $this->form_validation->set_rules('username', 'username', 'required|callback_validateuser[' . $query->num_rows() . ']');
  $this->form_validation->set_rules('password', 'password', 'required');
 
  $this->form_validation->set_error_delimiters('<div class="error">', '</div>');
  $this->form_validation->set_message('required', 'Enter %s');
 
  if ($this->form_validation->run() == FALSE) 
  {
   $this->load->view('sign-in');
    }else
    {
      if($query)
      {
       $query = $query->result();
      $home = array(
     'id' => $query[0]->id,
     'username' => $query[0]->username,
     'job_title' => $query[0]->job_title,
     'contact' => $query[0]->contact,
     'address' => $query[0]->address,
     'email' => $query[0]->email,
     'password' => $query[0]->password
    );
 
/*    $this->session->set_userdata($home);*/
    redirect('home/dashboard');
   }
  }
 }
 
 /** Custom Validation Method*/
 public function validateuser($username,$recordCount)
 {
  if ($recordCount != 0){
   return TRUE;
  }
  else
  {
   $this->form_validation->set_message('validateuser', 'Invalid %s or Password');
   return FALSE;
  }
 }

   function dashboard()
         {
$this->load->view('dashboard');
}


 public function forgotpassword()
      {
        $password = $this->input->post('password');
        $username = $this->input->post('username');
        $comfirmpassword=$this->input->post('comfirmpassword');
        $this->load->model("Insert");
        $result = $this->Insert->changepassword($password,$username);
        if($result)
        {
          $this->session->set_tempdata('changesuccess','Change Password Successfully',3);
          redirect('home/index');
        }
      }


     public function register()  
    {  

        $this->load->view('register');  

    } 

     public function registerdata()  
    {
            $username = $this->input->post('username');           
            $job_title = $this->input->post('job_title') ;
             $contact = $this->input->post('contact');           
            $address = $this->input->post('address') ;
             $email = $this->input->post('email');           
            $password = $this->input->post('password') ;

      
/* $this->form_validation->set_rules('id', 'Id', 'required');*/
  $this->form_validation->set_rules('username', 'username', 'required');
  $this->form_validation->set_rules('job_title', 'job_title', 'required');
  $this->form_validation->set_rules('contact', 'contact', 'required');
  $this->form_validation->set_rules('address', 'address', 'required');
  $this->form_validation->set_rules('email', 'email', 'required');
  $this->form_validation->set_rules('password', 'password', 'required');
            if ($this->form_validation->run() == FALSE)
           {  

              $this->load->view('register'); 
            } 
           else 
           {
              $this->load->model("Insert");
              $this->Insert->registerdb($id,$username,$job_title,$contact,$address,$email,$password);
              redirect('home/index');
           }
  }


 /*     Database Table-Blog-start...........................*/

       public function blog()  
    {
        $this->load->model("Insert");
          $records['data']=$this->Insert->selectrecords();
          $records['category']=$this->Insert->selectcategorydetails();
          $this->load->view('blog',$records);
    }

     public function insertdata()
     {     
          /*  $id = $this->input->post('id');*/
            $category = $this->input->post('category');
            $title = $this->input->post('title');
            $image = $this->input->post('image');
            $content = $this->input->post('content');
            $tags = $this->input->post('tags');
            $status = $this->input->post('status') ; 

/* $this->form_validation->set_rules('id', 'Id', 'required');*/
 $this->form_validation->set_rules('category', 'Category', 'required');
 $this->form_validation->set_rules('title', 'Title', 'required');
 $this->form_validation->set_rules('image','Image','required');
 $this->form_validation->set_rules('content', 'Content', 'required');
 $this->form_validation->set_rules('tags', 'Tags', 'required');

 if ($this->form_validation->run() !== FALSE)
           { 
               $this->load->view('blog'); 
           
           } 
           else 
           {                  
             $file_tmp = $_FILES['image']['tmp_name'];
             $file_name = $_FILES['image']['name'];
             $file_destination = 'uploads/' . $file_name;
    
            if (move_uploaded_file($file_tmp, $file_destination)) 
            {
              print("Received {$_FILES['image']['name']} - its size is {$_FILES['image']['size']}");
              $this->load->model("Insert");
              $this->Insert->insertdb($id,$category,$title,$file_name,$content,$tags,$status);
                 redirect('home/blog');
    
              } else {
                      print "Upload failed!";
                        /* redirect('home/blog');*/         
                     } 
          }

}

public function updateblog()
{   
      $id= $_GET["id"];
      $records['category']=$this->Insert->selectcategorydetails();
    /*  $records['image']=$this->Insert->selectimagedetails($file_name); */
      $records['data']=$this->Insert->selectblogtabledetails($id);    
      $this->load->view('updateblog',$records);
    
        /*if($this->input->post('updateblogrecords'))
        {*/         
}

public function updateblogrecords()
{
       $id=$this->input->post('id');    
       $category = $this->input->post('category');
       $title = $this->input->post('title');
       $image = $this->input->post('image');
       $content = $this->input->post('content');
       $tags = $this->input->post('tags');
       $status = $this->input->post('status') ; 


   /*    $records=$this->Insert->updateblogrecords($id,$category,$title,$file_name,$content,$tags,$status);
         redirect('home/blog');*/

             $file_tmp = $_FILES['image']['tmp_name'];
             $file_name = $_FILES['image']['name'];
             $file_destination = 'uploads/' . $file_name;
    
            if (move_uploaded_file($file_tmp, $file_destination)) 
            {
                              
              $this->Insert->updateblogdb($id,$category,$title,$file_name,$content,$tags,$status);
                 redirect('home/blog');
    
              } else {
                      print "Upload failed!";
                        /* redirect('home/blog');*/         
                     } 
}

public function deleteblog()
    {
       $id=$this->input->get('id');
    /* $category = $this->input->get('category');
       $title = $this->input->get('title');
       $image = $this->input->get('image');
       $content = $this->input->get('content');
       $tags = $this->input->get('tags');
       $status = $this->input->get('status') ; 
*/
  /*  $this->Insert->deleteblogrecords($id);*/
      $data = $this->Insert->deleteblogdb($id);
      $data['query'] = $this->Insert->deleteblogdb($id);
       redirect('home/blog');
    }


/*     Database Table-Blog-end...........................*/



/*     Database Table-Blog_category-start...........................*/

    public function blog_category()  
    {  
          $this->load->model("Insert");
          $records['data']=$this->Insert->selectcategory();
          $this->load->view('blog-category',$records);
    } 

    public function insertblog()
     {      
         /*   $id = $this->input->post('id');*/
            $category = $this->input->post('category');           
            $status = $this->input->post('status') ;

      
/* $this->form_validation->set_rules('id', 'Id', 'required');*/
       $this->form_validation->set_rules('category', 'Category', 'required');

            if ($this->form_validation->run() == FALSE)
           {  

              $this->load->view('blog-category'); 
           } 
           else 
           {
              $this->load->model("Insert");
              $this->Insert->insertblogdb($id,$category,$status);
              redirect('home/blog_category');
           }

     }


public function updateblogcategory()
{   
      $id= $_GET["id"];
      $records['data']=$this->Insert->selectcategorytabledetails($id);    
      $this->load->view('updateblogcategory',$records);
             
}

public function updatecategoryrecords()
{
       $id=$this->input->post('id');    
       $category = $this->input->post('category');
       $status = $this->input->post('status') ; 

       $this->Insert->updateblogcategorydb($id,$category,$status);
           redirect('home/blog_category');
     /*$id=$this->input->get('id');
     $records['data']=$this->Insert->updateblogcategoryrecords($id,$category,$status);

    $this->load->view('updateblogcategory',$records);
    
        if($this->input->post('updatecategoryrecords'))
        {
       $category = $this->input->post('category');
       $status = $this->input->post('status') ; 
       $records['data']= $this->Insert->updateblogcategoryrecords($id,$category,$status);
           redirect('home/blog_category');
        }*/
} 

public function deleteblogcategory()
    {
    $id=$this->input->get('id');
   
  $data = $this->Insert->deleteblogcategorydb($id);
$data['query'] = $this->Insert->deleteblogcategorydb($id);
        redirect('home/blog_category');
    }

/*     Database Table-Blog_category-end...........................*/



/*           Database Table-Career-start...........................*/

    public function career()  
    {  

       $this->load->model("Insert");
          $records['data']=$this->Insert->selectcareer();
         $this->load->view('career',$records);
    }  

 public function insertcareer()
     {
      
         /*  $id = $this->input->post('id');*/
            $title = $this->input->post('title');
            $image = $this->input->post('image');
            $content = $this->input->post('content');
           $status = $this->input->post('status') ;
           

/* $this->form_validation->set_rules('id', 'Id', 'required');*/
 $this->form_validation->set_rules('title', 'Title', 'required');
 $this->form_validation->set_rules('image','Image','required');
 $this->form_validation->set_rules('content', 'Content', 'required');

 if ($this->form_validation->run() !== FALSE)
           {  
              $this->load->view('career'); 
           } 
           else 
           {


        $file_tmp = $_FILES['image']['tmp_name'];
        $file_name = $_FILES['image']['name'];
        $file_destination = 'uploads/' . $file_name;

            if (move_uploaded_file($file_tmp, $file_destination)) 
            {
              print("Received {$_FILES['image']['name']} - its size is {$_FILES['image']['size']}");
              $this->load->model("Insert");
               $this->Insert->insertcareerdb($id,$title,$file_name,$content,$status);
                 redirect('home/career');
    
              } else {
                      print "Upload failed!";
                        /* redirect('home/blog');*/         
                     } 

           }

     }


     public function updatecareer()
{   
      $id= $_GET["id"];
      $records['data']=$this->Insert->selectcareertabledetails($id);    
      $this->load->view('updatecareer',$records);
            
}

public function updatecareerrecords()
{
       $id = $this->input->post('id');    
       $title = $this->input->post('title');
       $image = $this->input->post('image');
       $content = $this->input->post('content');
       $status = $this->input->post('status') ; 

           $file_tmp = $_FILES['image']['tmp_name'];
             $file_name = $_FILES['image']['name'];
             $file_destination = 'uploads/' . $file_name;
     
            if (move_uploaded_file($file_tmp, $file_destination)) 
            {
                              
              $this->Insert->updatecareerdb($id,$title,$file_name,$content,$status);
                 redirect('home/career');
    
              } else {
                      print "Upload failed!";
                                 
                     } 
}



public function deletecareer()
    {
    $id=$this->input->get('id');
    $data = $this->Insert->deletecareerdb($id);
$data['query'] = $this->Insert->deletecareerdb($id);
       redirect('home/career');
    }

 /*           Database Table-Career-end...........................*/


}  



?>  