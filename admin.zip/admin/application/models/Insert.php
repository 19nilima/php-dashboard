<?php

class Insert extends CI_Model
{ 

  function adminlogin($username,$password)
  {
  $this->db->select("id,username,job_title,contact,address,email,password");
  $whereCondition = $array = array('username' =>$username,'password'=>$password);
  $this->db->where($whereCondition);
  $this->db->from('register');
  $query = $this->db->get();
  return $query;
 }

 public function changepassword($password, $username)
  {
    /*$this->db->where('username', $username);
    $this->db->set('password', $password);
    $this->db->update('register');
    return true;*/


     date_default_timezone_set('Asia/Calcutta');
    $datetime = date("Y-m-d\TH:i:sP");

$query=$this->db->query("UPDATE register SET password='$password', datetime='$datetime' WHERE username='".$username."'");
   if($query){
      return true;
    }else{
      return false;
    }
  }


 public function registerdb($id,$username,$job_title,$contact,$address,$email,$password)
  {

     date_default_timezone_set('Asia/Calcutta');
    $datetime = date("Y-m-d\TH:i:sP");
            $data = array(
            'id' =>$id,
            'username' => $username,
            'job_title' => $job_title,
            'contact' =>  $contact,
            'address' => $address,
            'email' => $email,
            'password' => $password,
            'datetime' =>$datetime
        );
          $this->db->insert('register', $data);
    }


/*     Database Table-Blog-start...........................*/

  public function insertdb($id,$category,$title, $file_name,$content,$tags,$status)
  {

     date_default_timezone_set('Asia/Calcutta');
    $datetime = date("Y-m-d\TH:i:sP");
            $data = array(
            'id' =>$id,
            'category' => $category,
            'title' => $title,
            'image' =>  $file_name,
            'content' => $content,
            'tags' => $tags,
            'status' => $status,
            'datetime' =>$datetime

        );
          $this->db->insert('blog', $data);
    }

     public function selectcategorydetails()          /*  for category field*/
 {
          $this->db->reconnect();
          $query=$this->db->query("select * from blog_category");          
          return $query;

 }

    public function selectrecords()
    {

          $this->db->reconnect();
          $query=$this->db->query("select * from blog");
          return $query;
    }


public function updateblogdb($id,$category,$title,$file_name,$content,$tags,$status)
{
  
 date_default_timezone_set('Asia/Calcutta');
    $datetime = date("Y-m-d\TH:i:sP");

$query=$this->db->query("UPDATE blog SET category='$category', title='$title', image='$file_name', content='$content', tags='$tags', status='$status', datetime='$datetime' WHERE id='".$id."'");
  
}

  /*   public function selectimagedetails($file_name)        
 {
          $this->db->reconnect();
          $query=$this->db->query("SELECT image FROM blog");         
          return $query;

 }*/
     public function selectblogtabledetails($id)          /*  for all field*/
 {
          $this->db->reconnect();
          $query=$this->db->query("select * from  blog WHERE id='".$id."'");          
          return $query;

 }

public function deleteblogdb($id)
  {
  $this->db->query("DELETE  FROM blog WHERE id='".$id."'");
  }

/*      Database Table-Blog-end...........................*/


 /*    Database Table-Blog_category-start...........................*/

 public function insertblogdb($id,$category,$status)
  {
  date_default_timezone_set('Asia/Calcutta');
    $datetime = date("Y-m-d\TH:i:sP");
            $data = array(
            'id' => $id,
            'category' => $category,
            'status' => $status,
            'datetime' => $datetime          
        );
            $this->db->insert('blog_category', $data);          
    }

        public function selectcategory()
          {

          $this->db->reconnect();
          $query=$this->db->query("select * from blog_category");
          return $query;
         }


public function updateblogcategorydb($id,$category,$status)
{
   date_default_timezone_set('Asia/Calcutta');
    $datetime = date("Y-m-d\TH:i:sP");

   $query=$this->db->query("UPDATE blog_category SET category='$category', status='$status', datetime='$datetime' WHERE id='".$id."'");
}


    public function selectcategorytabledetails($id)          /*  for all field*/
 {
          $this->db->reconnect();
          $query=$this->db->query("select * from  blog_category WHERE id='".$id."'");          
          return $query;

 }

public function deleteblogcategorydb($id)
  {
  $this->db->query("DELETE  FROM blog_category WHERE id='".$id."'");
  }

/*     Database Table-Blog_category-end...........................*/


/*     Database Table-Career-start...........................*/

public function insertcareerdb($id,$title,$file_name,$content,$status)
  {
 date_default_timezone_set('Asia/Calcutta');
    $datetime = date("Y-m-d\TH:i:sP");
            $data = array(
            'id' => $id,
            'title' => $title,
            'image' => $file_name,
            'content' => $content,
            'status' => $status,
            'datetime' => $datetime
        );
            $this->db->insert('career', $data);
  
    }


     public function selectcareer()
          {

          $this->db->reconnect();
          $query=$this->db->query("select * from career");
          return $query;
         }

public function updatecareerdb($id,$title,$file_name,$content,$status)
{
  date_default_timezone_set('Asia/Calcutta');
    $datetime = date("Y-m-d\TH:i:sP");

   $query=$this->db->query("UPDATE career SET  title='$title', image='$file_name', content='$content',  status='$status', datetime='$datetime' WHERE id='".$id."'");
}


      public function selectcareertabledetails($id)          /*  for all field*/
 {
          $this->db->reconnect();
          $query=$this->db->query("select * from  career WHERE id='".$id."'");          
          return $query;

 }

 public function deletecareerdb($id)
  {
  $this->db->query("DELETE  FROM career WHERE id='".$id."'");
  }
/*     Database Table-Career-end...........................*/

}
?>


































<!-- public function insertcareerdb($id,$title, $file_name,$content,$status)
  {
 date_default_timezone_set('Asia/Calcutta');
    $datetime = date("Y-m-d\TH:i:sP");
            $data = array(
            'id' => $id,
            'title' => $title,
            'image' => $file_name,
            'content' => $content,
            'status' => $status,
            'datetime' => $datetime
            

        );
    $this->db->reconnect();
    $this->db->insert('career', $data);
  

       $query=$this->db->query("select * from career");
  return $query->result(); 

    }


}
?> -->