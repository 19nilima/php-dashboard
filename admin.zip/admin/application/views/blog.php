
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <title>Collective Admin Panel a Flat Bootstrap Responsive Website Template | Forms :: W3Layouts</title>

  <!-- Template CSS -->
 <link rel="stylesheet" href="<?php echo base_url();?>css/style-starter.css">

  <!-- google fonts -->
  <link href="//fonts.googleapis.com/css?family=Nunito:300,400,600,700,800,900&display=swap" rel="stylesheet">

</head>

<body class="sidebar-menu-collapsed">
<div class="se-pre-con"></div>
<section>
 

<?php include 'header.php';
?>


<!-- main content start -->
<div class="main-content">

    <!-- content -->
    <div class="container-fluid content-top-gap">

        <!-- breadcrumbs -->
        <nav aria-label="breadcrumb" class="mb-4">
            <ol class="breadcrumb my-breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo base_url()?>home">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Forms</li>
            </ol>
        </nav>
        <!-- //breadcrumbs -->
        <!-- forms -->
        <section class="forms">
       <!-- forms 2 -->
            <div class="card card_border py-2 mb-4">
                <div class="card-body">
               <?php echo validation_errors();?> 
              
              <form action="<?php echo base_url()?>home/insertdata" method="post"  enctype="multipart/form-data">
              
                       <?php echo form_open('form'); ?>

                      <div class="col-12">
                        <div class="form-row">
                            <!-- <div class="form-group col-2">
                                <label for="text" class="control-label">ID :-</label>
                              </div>
                              <div class="col-4">
                                <input type="text" class="form-control" name="id"
                                >
                                     
                            </div> -->
                            <div class="form-group col-2">
                                <label for="text" class="control-label">Category :-</label>
                              </div>
                              <div class="col-4">
                                
                                  <select class="form-control" name="category" id="category">
                  <option value='' >Select Category</option> 
                  <?php if(isset($category)){
                    foreach ($category->result() as $row) { ?>
                  <option value="<?php echo $row->category; ?>"><?php echo $row->category ?></option>
                  <?php }
                  }?>      
                </select>
                                  <!-- <input type="text" class="form-control" name="category"id="category"value="<?php echo $this->input->post('category'); ?>">
                                     <div class="error">
                                      <?php echo form_error('category');  ?>
                                  </div> -->
                            </div>
                            <div class="form-group col-2">
                                <label for="text" class="control-label">Title :-</label></div>
                                <div class="col-4">
                                <input type="text" class="form-control"  name="title"
                                  value="<?php echo $this->input->post('title'); ?>">
                                     <div class="error">
                                      <?php echo form_error('title');  ?>
                                  </div>
                            </div>



                          </div>
                        </div>
                          <div class="col-12">
                            <div class="row">                          
                             <div class="form-group col-2">
                                <label for="text" class="control-label">Image :-</label></div>
                                <div class="col-4">
                             
                                <input type="file"  name="image" value="<?php echo $this->input->post('image'); ?>" />
                              
                                 <div class="error">
                                      <?php echo form_error('image');?>
                                  </div> 
                            </div>
                             <div class="form-group col-2">
                                <label for="text" class="control-label">Content :-</label></div>
                                <div class="col-4">
                                <input type="text" class="form-control" name="content" value="<?php echo $this->input->post('content'); ?>">
                                     <div class="error">
                                      <?php echo form_error('content');  ?>
                                  </div>

                            </div>
                          </div>
                        </div>
                        <div class="col-12">
                          <div class="row">                           
                             <div class="form-group col-md-2">
                                <label for="text" class="control-label">Tag :-</label></div>
                                <div class="col-4">
                                <input type="text" class="form-control" name="tags" value="<?php echo $this->input->post('tags'); ?>">
                                  <div class="error">
                                      <?php echo form_error('tags');  ?>
                                  </div>
                            </div>
                            <div class="col-4">
                             <label for="cars">Status</label>
  <select id="status" name="status">
    <option value="active">Active</option>
    <option value="deactive">Deactive</option>
    
  </select></div>
                          </div>
                        </div>
                        <div class="col-6">                      
                        <button type="submit" class="btn btn-success">Submit</button>
                       <button type="reset" class="btn  btn-primary">Reset</button>
                        <button type="cancel" class="btn  btn-danger">Cancel</button></div>
                    </form>


                    <div class="col-12">
   <table  border="1" cellspacing="5" cellpadding="5" >
  <tr style="background:#CCC">
    <th>Sr No</th>
    <th>ID</th>   
    <th>Category</th>
    <th>Title</th>
   <th>Image</th>
   <th>Content</th>
   <th>Tag</th>
   <th>Status</th>
   <th>Date & Time</th>
   <th>Update</th>
   <th>Delete</th>
  </tr><?php
  $i=1;


  foreach($data->result() as $row)
  {
  echo "<tr>";
  echo "<td>".$i."</td>";
  echo "<td>".$row->id."</td>";
  echo "<td>".$row->category."</td>";
  echo "<td>".$row->title."</td>";
  echo "<td><img src=".base_url().'uploads/'.$row->image." width=50px; height=50px;/></td>";
  echo "<td>".$row->content."</td>";
  echo "<td>".$row->tags."</td>";
  echo "<td>".$row->status."</td>";
  echo "<td>".$row->datetime."</td>";
 /* echo "<td><a href=".base_url().'Home/updateblog/'.$row->id.">Update</a></td>";*/
 echo "<td><a href='updateblog?id=".$row->id."'>Update</a></td>";
 echo "<td><a href='deleteblog?id=".$row->id."'>Delete</a></td>";
/*  echo "<td><a href=".base_url().'Home/deleteblog/'.$row->id.">Delete</a></td>";*/
/*  echo "<td><a href=".base_url().'Home/updateblog/' "data-toggle=modal" "data-target=   #updateblog".$row->id.">Update</a></td>";*/
  echo "</tr>";
  $i++;
  }
   ?>
    
</table>
</div>
                </div>
            </div>
            <!-- //forms 2 -->

            

            

        </section>
        <!-- //forms -->
   


    </div>
    <!-- //content -->

</div>
<!-- main content end-->
</section>
<!--footer section start-->

<?php include 'footer.php';
?>

<!--footer section end-->






<!-- move top -->
<button onclick="topFunction()" id="movetop" class="bg-primary" title="Go to top">
  <span class="fa fa-angle-up"></span>
</button>
<script>
  // When the user scrolls down 20px from the top of the document, show the button
  window.onscroll = function () {
    scrollFunction()
  };

  function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
      document.getElementById("movetop").style.display = "block";
    } else {
      document.getElementById("movetop").style.display = "none";
    }
  }

  // When the user clicks on the button, scroll to the top of the document
  function topFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
  }
</script>
<!-- /move top -->


<script src="<?php echo base_url();?>js/jquery-3.3.1.min.js"></script>
<script src="<?php echo base_url();?>js/jquery-1.10.2.min.js"></script>

<!-- chart js -->
<script src="<?php echo base_url();?>js/Chart.min.js"></script>
<script src="<?php echo base_url();?>js/utils.js"></script>
<!-- //chart js -->

<!-- Different scripts of charts.  Ex.Barchart, Linechart -->
<script src="<?php echo base_url();?>js/bar.js"></script>
<script src="<?php echo base_url();?>js/linechart.js"></script>
<!-- //Different scripts of charts.  Ex.Barchart, Linechart -->


<script src="<?php echo base_url();?>js/jquery.nicescroll.js"></script>
<script src="<?php echo base_url();?>js/scripts.js"></script>

<!-- close script -->
<script>
  var closebtns = document.getElementsByClassName("close-grid");
  var i;

  for (i = 0; i < closebtns.length; i++) {
    closebtns[i].addEventListener("click", function () {
      this.parentElement.style.display = 'none';
    });
  }
</script>
<!-- //close script -->

<!-- disable body scroll when navbar is in active -->
<script>
  $(function () {
    $('.sidebar-menu-collapsed').click(function () {
      $('body').toggleClass('noscroll');
    })
  });
</script>
<!-- disable body scroll when navbar is in active -->

 <!-- loading-gif Js -->
 <script src="<?php echo base_url();?>js/modernizr.js"></script>
 <script>
     $(window).load(function () {
         // Animate loader off screen
         $(".se-pre-con").fadeOut("slow");;
     });
 </script>
 <!--// loading-gif Js -->

<!-- Bootstrap Core JavaScript -->
<script src="<?php echo base_url();?>js/bootstrap.min.js"></script>


</body>

</html>