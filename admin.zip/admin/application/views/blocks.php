<!--
Author: W3layouts
Author URL: http://w3layouts.com
-->
<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <title>Collective Admin Panel a Flat Bootstrap Responsive Website Template | Content Blocks :: W3Layouts</title>

  <!-- Template CSS -->
  <link rel="stylesheet" href="assets/css/style-starter.css">

  <!-- google fonts -->
  <link href="//fonts.googleapis.com/css?family=Nunito:300,400,600,700,800,900&display=swap" rel="stylesheet">
</head>

<body class="sidebar-menu-collapsed">
<div class="se-pre-con"></div>
<section>
  <!-- sidebar menu start -->
  <div class="sidebar-menu sticky-sidebar-menu">

    <!-- logo start -->
    <div class="logo">
      <h1><a href="index.html">Collective</a></h1>
    </div>

  <!-- if logo is image enable this -->
    <!-- image logo --
    <div class="logo">
      <a href="index.html">
        <img src="image-path" alt="Your logo" title="Your logo" class="img-fluid" style="height:35px;" />
      </a>
    </div>
     //image logo -->

    <div class="logo-icon text-center">
      <a href="index.html" title="logo"><img src="assets/images/logo.png" alt="logo-icon"> </a>
    </div>
    <!-- //logo end -->

    <div class="sidebar-menu-inner">

      <!-- sidebar nav start -->
      <ul class="nav nav-pills nav-stacked custom-nav">
        <li><a href="index.html"><i class="fa fa-tachometer"></i><span> Dashboard</span></a>
        </li>
        <li class="menu-list">
          <a href="#"><i class="fa fa-cogs"></i>
            <span>Elements <i class="lnr lnr-chevron-right"></i></span></a>
          <ul class="sub-menu-list">
            <li><a href="carousels.html">Carousels</a> </li>
            <li><a href="cards.html">Default cards</a> </li>
            <li><a href="people.html">People cards</a></li>
          </ul>
        </li>
        <li><a href="pricing.html"><i class="fa fa-table"></i> <span>Pricing tables</span></a></li>
        <li class="active"><a href="blocks.html"><i class="fa fa-th"></i> <span>Content blocks</span></a></li>
        <li><a href="forms.html"><i class="fa fa-file-text"></i> <span>Forms</span></a></li>
      </ul>
      <!-- //sidebar nav end -->
      <!-- toggle button start -->
      <a class="toggle-btn">
        <i class="fa fa-angle-double-left menu-collapsed__left"><span>Collapse Sidebar</span></i>
        <i class="fa fa-angle-double-right menu-collapsed__right"></i>
      </a>
      <!-- //toggle button end -->
    </div>
  </div>
  <!-- //sidebar menu end -->
  <!-- header-starts -->
  <div class="header sticky-header">

    <!-- notification menu start -->
    <div class="menu-right">
      <div class="navbar user-panel-top">
        <div class="search-box">
          <form action="#search-results.html" method="get">
            <input class="search-input" placeholder="Search Here..." type="search" id="search">
            <button class="search-submit" value=""><span class="fa fa-search"></span></button>
          </form>
        </div>
        <div class="user-dropdown-details d-flex">
          <div class="profile_details_left">
            <ul class="nofitications-dropdown">
              <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i
                    class="fa fa-bell-o"></i><span class="badge blue">3</span></a>
                <ul class="dropdown-menu">
                  <li>
                    <div class="notification_header">
                      <h3>You have 3 new notifications</h3>
                    </div>
                  </li>
                  <li><a href="#" class="grid">
                      <div class="user_img"><img src="assets/images/avatar1.jpg" alt=""></div>
                      <div class="notification_desc">
                        <p>Johnson purchased template</p>
                        <span>Just Now</span>
                      </div>
                    </a></li>
                  <li class="odd"><a href="#" class="grid">
                      <div class="user_img"><img src="assets/images/avatar2.jpg" alt=""></div>
                      <div class="notification_desc">
                        <p>New customer registered </p>
                        <span>1 hour ago</span>
                      </div>
                    </a></li>
                  <li><a href="#" class="grid">
                      <div class="user_img"><img src="assets/images/avatar3.jpg" alt=""></div>
                      <div class="notification_desc">
                        <p>Lorem ipsum dolor sit amet </p>
                        <span>2 hours ago</span>
                      </div>
                    </a></li>
                  <li>
                    <div class="notification_bottom">
                      <a href="#all" class="bg-primary">See all notifications</a>
                    </div>
                  </li>
                </ul>
              </li>
              <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i
                    class="fa fa-comment-o"></i><span class="badge blue">4</span></a>
                <ul class="dropdown-menu">
                  <li>
                    <div class="notification_header">
                      <h3>You have 4 new messages</h3>
                    </div>
                  </li>
                  <li><a href="#" class="grid">
                      <div class="user_img"><img src="assets/images/avatar1.jpg" alt=""></div>
                      <div class="notification_desc">
                        <p>Johnson purchased template</p>
                        <span>Just Now</span>
                      </div>
                    </a></li>
                  <li class="odd"><a href="#" class="grid">
                      <div class="user_img"><img src="assets/images/avatar2.jpg" alt=""></div>
                      <div class="notification_desc">
                        <p>New customer registered </p>
                        <span>1 hour ago</span>
                      </div>
                    </a></li>
                  <li><a href="#" class="grid">
                      <div class="user_img"><img src="assets/images/avatar3.jpg" alt=""></div>
                      <div class="notification_desc">
                        <p>Lorem ipsum dolor sit amet </p>
                        <span>2 hours ago</span>
                      </div>
                    </a></li>
                  <li><a href="#" class="grid">
                      <div class="user_img"><img src="assets/images/avatar1.jpg" alt=""></div>
                      <div class="notification_desc">
                        <p>Johnson purchased template</p>
                        <span>Just Now</span>
                      </div>
                    </a></li>
                  <li>
                    <div class="notification_bottom">
                      <a href="#all" class="bg-primary">See all messages</a>
                    </div>
                  </li>
                </ul>
              </li>
            </ul>
          </div>
          <div class="profile_details">
            <ul>
              <li class="dropdown profile_details_drop">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" id="dropdownMenu3" aria-haspopup="true"
                  aria-expanded="false">
                  <div class="profile_img">
                    <img src="assets/images/profileimg.jpg" class="rounded-circle" alt="" />
                    <div class="user-active">
                      <span></span>
                    </div>
                  </div>
                </a>
                <ul class="dropdown-menu drp-mnu" aria-labelledby="dropdownMenu3">
                  <li class="user-info">
                    <h5 class="user-name">John Deo</h5>
                    <span class="status ml-2">Available</span>
                  </li>
                  <li> <a href="#"><i class="lnr lnr-user"></i>My Profile</a> </li>
                  <li> <a href="#"><i class="lnr lnr-users"></i>1k Followers</a> </li>
                  <li> <a href="#"><i class="lnr lnr-cog"></i>Setting</a> </li>
                  <li> <a href="#"><i class="lnr lnr-heart"></i>100 Likes</a> </li>
                  <li class="logout"> <a href="#sign-up.html"><i class="fa fa-power-off"></i> Logout</a> </li>
                </ul>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <!--notification menu end -->
  </div>
  <!-- //header-ends -->
<!-- main content start -->
<div class="main-content">

  <!-- content -->
  <div class="container-fluid content-top-gap">

    <!-- breadcrumbs -->
    <nav aria-label="breadcrumb" class="mb-4">
      <ol class="breadcrumb my-breadcrumb">
        <li class="breadcrumb-item"><a href="index.html">Home</a></li>
        <li class="breadcrumb-item"><a href="#">Elements</a></li>
        <li class="breadcrumb-item active" aria-current="page">Content Blocks</li>
      </ol>
    </nav>
    <!-- //breadcrumbs -->

    <!-- card heading -->
    <div class="cards__heading">
      <h3>Content Blocks</h3>
    </div>
    <!-- //card heading -->

    <!-- content block style 1-->
    <div class="card card_border p-lg-5 p-3 mb-4">
      <div class="card-body py-3 p-0">
        <div class="row">
          <div class="col-lg-6 align-self pr-lg-4">
            <h3 class="block__title mb-lg-4">About Content Block</h3>
            <p class="mb-3">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Accusa ntium corrupti
              neque sunt labore veritatis. </p>
            <p class="mb-lg-5 mb-3">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Accusa ntium corrupti
              neque sunt
              praesentium aut, labore veritatis. Eaque, similique aspernatur. Perferendis doloremque ut
              praesentium vel voluptatum quasi dolor explicabo nobis ex?</p>
            <a href="#read" class="btn btn-style btn-primary"> Read More</a>
          </div>
          <div class="col-lg-6 pl-lg-4 mt-lg-0 mt-4">
            <img src="assets/images/template2.jpg" alt="" class="img-fluid rounded" />
          </div>
        </div>
      </div>
    </div>
    <!-- //content block style 1-->

    <!-- content block style 2-->
    <div class="card card_border p-lg-5 p-3 mb-4">
      <div class="card-body py-3 p-0">
        <div class="row">
          <div class="col-lg-6 pr-lg-4">
            <img src="assets/images/template1.jpg" alt="" class="img-fluid rounded" />
          </div>
          <div class="col-lg-6 align-self pl-lg-4 mt-lg-0 mt-4">
            <h3 class="block__title mb-lg-4">Content Block with 2 buttons</h3>
            <p class="mb-3">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Accusa ntium corrupti neque sunt
              praesentium aut, labore veritatis. Eaque, similique aspernatur. Perferendis doloremque ut
              praesentium vel voluptatum quasi dolor explicabo nobis ex?</p>
            <p class="mb-lg-5 mb-3">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Accusa ntium corrupti
              neque sunt labore veritatis.</p>
            <a href="#read" class="btn btn-style btn-primary mr-2"> Read More</a>
            <a href="#more" class="btn btn-style border-btn"> Contact Us</a>
          </div>
        </div>
      </div>
    </div>
    <!-- //content block style 2-->

    <!-- content block style 3 -->
    <div class="card card_border p-lg-5 p-3 mb-4">
      <div class="card-body py-3 p-0">
        <div class="row">
          <div class="col-lg-6 align-self pr-lg-4">
            <h3 class="block__title mb-lg-4">Content Block with list features</h3>
            <p class="mb-3">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Accusa ntium corrupti
              neque sunt aut, labore veritatis. </p>
            <ul class="block-list">
              <li>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</li>
              <li>Accusa ntium corrupti neque sunt praesentium aut, labore veritatis accusa ntium nobis ex.</li>
              <li>Eaque, similique aspernatur. Perferendis doloremque ut </li>
              <li>praesentium vel voluptatum quasi dolor explicabo nobis ex?</li>
              <li>Lorem ipsum dolor sit amet, adipisicing elit.</li>
            </ul>
          </div>
          <div class="col-lg-6 pl-lg-4 mt-lg-0 mt-4">
            <img src="assets/images/dashboard.jpg" alt="" class="img-fluid rounded" />
          </div>
        </div>
      </div>
    </div>
    <!-- //content block style 3 -->

    <!-- content block style 4 -->
    <div class="card card_border p-lg-5 p-3 mb-4">
      <div class="card-body py-3 p-0">
        <h3 class="block__title mb-lg-4">Content Block Grids</h3>
        <div class="row">
          <div class="col-md-4 column mt-md-3 mt-3">
            <a href="#img1"><img class="img-fluid rounded" src="assets/images/template2.jpg" alt=""></a>
            <a href="#para1">
              <p class="grid-para">Lorem ipsum dolor sit amet consectetur adipisicing.</p>
            </a>
            <a href="#caption1">
              <p class="paragraph text-primary">caption</p>
            </a>
          </div>
          <div class="col-md-4 column mt-md-3 mt-5">
            <a href="#img1"><img class="img-fluid rounded" src="assets/images/cart.jpg" alt=""></a>
            <a href="#para2">
              <p class="grid-para">Lorem ipsum dolor sit amet consectetur adipisicing.</p>
            </a>
            <a href="#caption2">
              <p class="paragraph text-primary">caption</p>
            </a>
          </div>
          <div class="col-md-4 column mt-md-3 mt-5">
            <a href="#img1"><img class="img-fluid rounded" src="assets/images/dashboard.jpg" alt=""></a>
            <a href="#para3">
              <p class="grid-para">Lorem ipsum dolor sit amet consectetur adipisicing.</p>
            </a>
            <a href="#caption3">
              <p class="paragraph text-primary">caption</p>
            </a>
          </div>
        </div>
      </div>
    </div>
    <!-- //content block style 4 -->

    <!-- content block style 5 -->
    <div class="card card_border p-lg-5 p-3 mb-4">
      <div class="card-body py-3 p-0">
        <h3 class="block__title mb-lg-4">Content Block Features with photo</h3>
        <div class="row cwp23-content align-items-lg-center">
          <div class="cwp23-img col-md-6 pt-md-4 mt-md-0 mt-3">
            <img src="assets/images/content.jpg" class="img-fluid rounded" alt="">
          </div>
          <div class="cwp23-text col-md-6 mt-4 mt-md-0 pl-md-4">
            <div class="cwp23-title">
              <h3>Features with photo, you are in a good company </h3>
            </div>
            <div class="row cwp23-text-cols">
              <div class="column col-lg-6 mt-4">
                <h4 class="text-primary">Feature One</h4>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor </p>
              </div>
              <div class="column col-lg-6 mt-4">
                <h4 class="text-primary">Feature Two</h4>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor </p>
              </div>
              <div class="column col-lg-6 mt-4">
                <h4 class="text-primary">Feature Three</h4>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor </p>
              </div>
              <div class="column col-lg-6 mt-4">
                <h4 class="text-primary">Feature Four</h4>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- //content block style 5 -->

    <!-- content block style 6 -->
    <div class="card card_border p-lg-5 p-3 mb-4">
      <div class="card-body py-3 p-0">
        <h3 class="block__title mb-lg-4">Content Block Features</h3>
        <div class="row feature-3 text-center">
          <div class="col-md-4 three-grids-columns mt-5">
            <span class="fa fa-laptop icon-fea" aria-hidden="true"></span>
            <a href="#">

              <h4>Web Design</h4>
            </a>
            <p>Lorem ipsum dolor sit amet,Ea consequuntur illum facere aperiam sequi optio consectetur.</p>

            <a href="#" class="actionbg">Read More</a>
          </div>
          <div class="col-md-4 three-grids-columns mt-5">
            <span class="fa fa-paint-brush icon-fea" aria-hidden="true"></span>
            <a href="#">

              <h4>Graphic Design</h4>
            </a>
            <p>Lorem ipsum dolor sit amet,Ea consequuntur illum facere aperiam sequi optio consectetur.</p>
            <a href="#" class="actionbg">Read More</a>
          </div>
          <div class="col-md-4 three-grids-columns mt-5">
            <span class="fa fa-signal icon-fea" aria-hidden="true"></span>
            <a href="#">

              <h4>Web Development</h4>
            </a>
            <p>Lorem ipsum dolor sit amet,Ea consequuntur illum facere aperiam sequi optio consectetur.</p>
            <a href="#" class="actionbg">Read More</a>
          </div>
        </div>
      </div>
    </div>
    <!-- //content block style 6 -->

    <!-- content block style 7 -->
    <div class="w3l-about1 card card_border p-lg-5 p-3 mb-4">
      <div class="card-body py-3 p-0">
        <h3 class="block__title mb-lg-4">Content Block Features with photo</h3>
        <div class="row cwp23-content">
          <div class="col-md-6 cwp23-text">
            <div class="row cwp23-text-cols">
              <div class="col-md-6 column mt-4">
                <span class="fa fa-laptop icon-fea" aria-hidden="true"></span>
                <a href="#url">Web design</a>
                <p>Type your text here... Lorem ipsum dolor sit amet. </p>
              </div>
              <div class="col-md-6 column mt-4">
                <span class="fa fa-paint-brush icon-fea" aria-hidden="true"></span>
                <a href="#url">Graphic design</a>
                <p>Type your text here... Lorem ipsum dolor sit amet. </p>
              </div>
              <div class="col-md-6 column mt-4">
                <span class="fa fa-signal icon-fea" aria-hidden="true"></span>
                <a href="#url">Web development</a>
                <p>Type your text here... Lorem ipsum dolor sit amet. </p>
              </div>
              <div class="col-md-6 column mt-4">
                <span class="fa fa-laptop icon-fea" aria-hidden="true"></span>
                <a href="#url">Webdesign</a>
                <p>Type your text here... Lorem ipsum dolor sit amet. </p>
              </div>
            </div>
          </div>
          <div class="col-md-6 mt-md-0 mt-5 cwp23-img">
            <img src="assets/images/template2.jpg" class="img-fluid rounded" alt="">
          </div>
        </div>
      </div>
    </div>
    <!-- //content block style 7 -->

  </div>
  <!-- //content -->

</div>
<!-- main content end-->
</section>
<!--footer section start-->
<footer class="dashboard">
  <p>&copy 2020 Collective. All Rights Reserved | Design by <a href="https://w3layouts.com/" target="_blank"
      class="text-primary">W3layouts.</a></p>
</footer>
<!--footer section end-->
<!-- move top -->
<button onclick="topFunction()" id="movetop" class="bg-primary" title="Go to top">
  <span class="fa fa-angle-up"></span>
</button>
<script>
  // When the user scrolls down 20px from the top of the document, show the button
  window.onscroll = function () {
    scrollFunction()
  };

  function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
      document.getElementById("movetop").style.display = "block";
    } else {
      document.getElementById("movetop").style.display = "none";
    }
  }

  // When the user clicks on the button, scroll to the top of the document
  function topFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
  }
</script>
<!-- /move top -->


<script src="assets/js/jquery-3.3.1.min.js"></script>
<script src="assets/js/jquery-1.10.2.min.js"></script>

<!-- chart js -->
<script src="assets/js/Chart.min.js"></script>
<script src="assets/js/utils.js"></script>
<!-- //chart js -->

<!-- Different scripts of charts.  Ex.Barchart, Linechart -->
<script src="assets/js/bar.js"></script>
<script src="assets/js/linechart.js"></script>
<!-- //Different scripts of charts.  Ex.Barchart, Linechart -->


<script src="assets/js/jquery.nicescroll.js"></script>
<script src="assets/js/scripts.js"></script>

<!-- close script -->
<script>
  var closebtns = document.getElementsByClassName("close-grid");
  var i;

  for (i = 0; i < closebtns.length; i++) {
    closebtns[i].addEventListener("click", function () {
      this.parentElement.style.display = 'none';
    });
  }
</script>
<!-- //close script -->

<!-- disable body scroll when navbar is in active -->
<script>
  $(function () {
    $('.sidebar-menu-collapsed').click(function () {
      $('body').toggleClass('noscroll');
    })
  });
</script>
<!-- disable body scroll when navbar is in active -->

 <!-- loading-gif Js -->
 <script src="assets/js/modernizr.js"></script>
 <script>
     $(window).load(function () {
         // Animate loader off screen
         $(".se-pre-con").fadeOut("slow");;
     });
 </script>
 <!--// loading-gif Js -->

<!-- Bootstrap Core JavaScript -->
<script src="assets/js/bootstrap.min.js"></script>

</body>

</html>