<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <title>Welcome to webisoftech</title>

  <!-- Template CSS -->
  <link rel="stylesheet" href="css/style-starter.css">
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <!-- google fonts -->
  <link href="//fonts.googleapis.com/css?family=Nunito:300,400,600,700,800,900&display=swap" rel="stylesheet">
  <style>
    h3 {
    color: saddlebrown;
}
/*.error {
    position: relative;
    top: -14px;
}*/
  </style>
</head>

<div class="col-12 adminblog"   style="background: url(images/bg.jpeg); background-repeat: no-repeat;    background-size: cover;">
  
  <!-- forms -->
  <section class="forms" id="forms">
    

       <!-- forms 2 -->
            <div class="card card_border" style="text-align: center;">
                  <div class="heading">
                  <h3> Sign In to <strong>ADMIN</strong></h3>
                </div>

            <div class="card-body" style="text-align: center;">
            <form  action=" " method="post">
                <?php echo form_open('form'); ?>
              <div class="log-input">
                   <i class="fa fa-user" aria-hidden="true"></i>
                   <input type="text"id="username" name="username" class="user" placeholder="User name" value="<?php echo $this->input->post('username'); ?>">
                    <div class="error">
                    <?php echo form_error('username');  ?>
                    </div>
              </div>
              
              <div class="log-input">
                   <i class="fa fa-lock" aria-hidden="true"></i>
                   <input type="password" id="password"class="lock" name="password" placeholder="Password" value="<?php echo $this->input->post('password'); ?>">
                   <!--  <div class="error">
                    <?php echo form_error('password');  ?>
                    </div> -->
               </div>
              
              <div class="log-input">
              <input type="submit" name="login" class="log-input-left" value="Login to your account">
              </div>

              <div class="log-input" id="input">
              <a href="" data-toggle="modal" data-target="#forgotPassword"><i class="fa fa-key"></i> Forgot Password</a> 
              <a style="float: right;"  href="<?php echo base_url();?>home/register"> Register</a>
            </div>
</form>
</div>
</div>

</section>
</div>
</div>

<!--footer section start-->

<?php include 'footer.php';
?>

<!--footer section end-->

<div id="forgotPassword" class="modal">
<div class="modal-dialog">
<div class="modal-content">
  <div class="modal-header text-center">
    <h4 class="modal-title" id="proSuccess">Change Password</h4>
  </div>
  <div class="modal-body">
    <form class="form-horizontal" name="forgotPasswordForm"  id="forgotPasswordForm" action=" " method="post" enctype="muiltipart/form-data">
              <fieldset>
             <div class="col-lg-12 form-group">
              
              <div class="col-lg-12">
                <label for="input" class="control-label">User name <span style="color: red;">*</span></label>
                <input class="form-control1" value="<?php echo $this->input->post('username'); ?>" id="username" placeholder="username" name="username" type="text">
                <?php
                echo form_error('username'); 
                ?>
              </div>

              <div class="col-lg-12">
                <label for="input" class="control-label">Change Password <span style="color: red;">*</span></label>
                <input class="form-control1" value="<?php echo $this->input->post('password'); ?>" id="password" placeholder="Password" name="password" type="Password">
                <?php
                echo form_error('password'); 
                ?>
              </div>
              
              <div class="col-lg-12">
                <label for="input" class="control-label">Confirm Password <span style="color: red;">*</span></label>
                <input class="form-control1" value="<?php echo $this->input->post('password'); ?>" id="confirmpassword" placeholder="Confirm password" name="confirmpassword" type="Password">
                <?php
                echo form_error('password'); 
                ?>
              </div>
            </div>             
            <div class="col-lg-12 form-group text-center">
              <button type="submit" class="btn btn-md btn-primary">Submit</button>
              <button type="reset" class="btn btn-md btn-default">Reset</button>
              <a class="btn btn-md btn-default" data-dismiss="modal">Cancel</a>
            </div>
            </fieldset>
          </form>
  </div>
</div>
</div>
</div>  


<!-- move top -->
<!-- <button onclick="topFunction()" id="movetop" class="bg-primary" title="Go to top">
  <span class="fa fa-angle-up"></span>
</button> -->
<script>
  // When the user scrolls down 20px from the top of the document, show the button
  window.onscroll = function () {
    scrollFunction()
  };

  function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
      document.getElementById("movetop").style.display = "block";
    } else {
      document.getElementById("movetop").style.display = "none";
    }
  }

  // When the user clicks on the button, scroll to the top of the document
  function topFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
  }
</script>
<!-- /move top -->


<script src="js/jquery-3.3.1.min.js"></script>
<script src="js/jquery-1.10.2.min.js"></script>

<!-- chart js -->
<script src="js/Chart.min.js"></script>
<script src="js/utils.js"></script>
<!-- //chart js -->

<!-- Different scripts of charts.  Ex.Barchart, Linechart -->
<script src="js/bar.js"></script>
<script src="js/linechart.js"></script>
<!-- //Different scripts of charts.  Ex.Barchart, Linechart -->


<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>

<!-- close script -->
<script>
  var closebtns = document.getElementsByClassName("close-grid");
  var i;

  for (i = 0; i < closebtns.length; i++) {
    closebtns[i].addEventListener("click", function () {
      this.parentElement.style.display = 'none';
    });
  }
</script>
<!-- //close script -->

<!-- disable body scroll when navbar is in active -->
<script>
  $(function () {
    $('.sidebar-menu-collapsed').click(function () {
      $('body').toggleClass('noscroll');
    })
  });
</script>
<!-- disable body scroll when navbar is in active -->

 <!-- loading-gif Js -->
 <script src="js/modernizr.js"></script>
 <script>
     $(window).load(function () {
         // Animate loader off screen
         $(".se-pre-con").fadeOut("slow");;
     });
 </script>
 <!--// loading-gif Js -->

<!-- Bootstrap Core JavaScript -->
<script src="assets/js/bootstrap.min.js"></script>

</body>

</html>
  