<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <title>Welcome to webisoftech</title>

  <!-- Template CSS -->
  <link rel="stylesheet" href="css/style-starter.css">

  <!-- google fonts -->
  <link href="//fonts.googleapis.com/css?family=Nunito:300,400,600,700,800,900&display=swap" rel="stylesheet">
  <style>
    label.control-label {
    margin-right: 45px;
    font-size: 20px;
}
.log-input {
    padding-bottom: 25px;
}
form {
    text-align: right;
    margin-right: 36%;
}
  </style>

</head>

<div class="adminblog"   style="background: url(images/bg.jpeg); background-repeat: no-repeat;    background-size: cover;">
  
  <!-- forms -->
  <section class="forms">
    

       <!-- forms 2 -->
            <div class="card_border1">
                  <div class="heading1">
                  <h2 style="text-align: center;"><strong> Register</strong></h2>
                </div>
<!-- 
            <div class="card-body" style="text-align: center;"> -->
            <form  action="<?php echo base_url()?>home/registerdata" method="post"  enctype="multipart/form-data">
              <?php echo form_open('form'); ?>
              <div class="log-input">
                    <label for="text" class="control-label">Name :-</label>
                   <input type="text" name="username"  style="background-color: transparent; padding: 5px;
    width: 30%;" value="<?php echo $this->input->post('username'); ?>">
                                     <div class="error">
                                      <?php echo form_error('username');  ?>
                                  </div>
              </div>

               <div class="log-input">
                    <label for="text" class="control-label">Job Title :-</label>
                   <input type="text" name="job_title" style="background-color: transparent; padding: 5px;
    width: 30%;"value="<?php echo $this->input->post('job_title'); ?>">
                                     <div class="error">
                                      <?php echo form_error('job_title');  ?>
                                  </div>
              </div>
              
              <div class="log-input">
                    <label for="text" class="control-label">Contact :-</label>
                   <input type="text" name="contact" style="background-color: transparent; padding: 5px;
    width: 30%;" value="<?php echo $this->input->post('contact'); ?>">
                                     <div class="error">
                                      <?php echo form_error('contact');  ?>
                                  </div>
               </div>
                <div class="log-input">
                    <label for="text" class="control-label">Address :-</label>
                   <input type="text" name="address" style="background-color: transparent; padding: 5px;
    width: 30%;" value="<?php echo $this->input->post('address'); ?>">
                                     <div class="error">
                                      <?php echo form_error('address');  ?>
                                  </div>
              </div>
               <div class="log-input">
                    <label for="text" class="control-label">Email :-</label>
                   <input type="text" name="email" style="background-color: transparent; padding: 5px;
    width: 30%;" value="<?php echo $this->input->post('email'); ?>">
                                     <div class="error">
                                      <?php echo form_error('email');  ?>
                                  </div>
              </div>
               <div class="log-input">
                  <label for="password" class="control-label">Password :-</label>
                   <input type="password" name="password" style="background-color: transparent; padding: 5px;
    width: 30%;" value="<?php echo $this->input->post('password'); ?>">
                                     <div class="error">
                                      <?php echo form_error('password');  ?>
                                  </div>
              </div>
              <button type="submit" class="btn btn-primary">Submit</button>
              
</form>
</div>
</div>
</section>
</div>


<!--footer section start-->

<?php include 'footer.php';
?>

<!--footer section end-->




<!-- move top -->
<!-- <button onclick="topFunction()" id="movetop" class="bg-primary" title="Go to top">
  <span class="fa fa-angle-up"></span>
</button> -->
<script>
  // When the user scrolls down 20px from the top of the document, show the button
  window.onscroll = function () {
    scrollFunction()
  };

  function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
      document.getElementById("movetop").style.display = "block";
    } else {
      document.getElementById("movetop").style.display = "none";
    }
  }

  // When the user clicks on the button, scroll to the top of the document
  function topFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
  }
</script>
<!-- /move top -->


<script src="js/jquery-3.3.1.min.js"></script>
<script src="js/jquery-1.10.2.min.js"></script>

<!-- chart js -->
<script src="js/Chart.min.js"></script>
<script src="js/utils.js"></script>
<!-- //chart js -->

<!-- Different scripts of charts.  Ex.Barchart, Linechart -->
<script src="js/bar.js"></script>
<script src="js/linechart.js"></script>
<!-- //Different scripts of charts.  Ex.Barchart, Linechart -->


<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>

<!-- close script -->
<script>
  var closebtns = document.getElementsByClassName("close-grid");
  var i;

  for (i = 0; i < closebtns.length; i++) {
    closebtns[i].addEventListener("click", function () {
      this.parentElement.style.display = 'none';
    });
  }
</script>
<!-- //close script -->

<!-- disable body scroll when navbar is in active -->
<script>
  $(function () {
    $('.sidebar-menu-collapsed').click(function () {
      $('body').toggleClass('noscroll');
    })
  });
</script>
<!-- disable body scroll when navbar is in active -->

 <!-- loading-gif Js -->
 <script src="js/modernizr.js"></script>
 <script>
     $(window).load(function () {
         // Animate loader off screen
         $(".se-pre-con").fadeOut("slow");;
     });
 </script>
 <!--// loading-gif Js -->

<!-- Bootstrap Core JavaScript -->
<script src="assets/js/bootstrap.min.js"></script>

</body>

</html>
  